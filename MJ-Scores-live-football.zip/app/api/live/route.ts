import {NextResponse} from "next/server";
export async function GET(){
 const key=process.env.SPORTS_API_KEY;
 if(!key)return NextResponse.json({error:"SPORTS_API_KEY is not configured"},{status:500});
 const r=await fetch("https://v3.football.api-sports.io/fixtures?live=all",{headers:{"x-apisports-key":key},cache:"no-store"});
 if(!r.ok)return NextResponse.json({error:"Sports API error: "+r.status},{status:r.status});
 return NextResponse.json(await r.json());
}